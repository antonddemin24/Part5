import {
  require_react
} from "/node_modules/.vite/deps/chunk-BZN7XFWI.js?v=0a8c374f";
import "/node_modules/.vite/deps/chunk-76J2PTFD.js?v=0a8c374f";
export default require_react();
//# sourceMappingURL=react.js.map
