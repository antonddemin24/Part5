import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0a8c374f"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Blog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=0a8c374f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import blogService from "/src/services/blogs.js";
import __vite__cjsImport5_propTypes from "/node_modules/.vite/deps/prop-types.js?v=0a8c374f"; const PropTypes = __vite__cjsImport5_propTypes.__esModule ? __vite__cjsImport5_propTypes.default : __vite__cjsImport5_propTypes;
const Blog = ({
  blog,
  user,
  setBlogs,
  blogs,
  updateBlog
}) => {
  _s();
  const [detailsVisible, setDetailsVisible] = useState(false);
  const blogStyle = {
    paddingTop: 10,
    paddingLeft: 2,
    border: "solid",
    borderWidth: 1,
    marginBottom: 5
  };
  const toggleDetails = () => {
    setDetailsVisible(!detailsVisible);
  };
  const handleLike = async () => {
    const updatedBlog = {
      ...blog,
      likes: blog.likes + 1
    };
    await blogService.update(blog.id, updatedBlog);
    updateBlog(blog.id, updatedBlog);
  };
  const handleDelete = async () => {
    if (window.confirm(`Remove blog "${blog.title}" by ${blog.author}?`)) {
      try {
        await blogService.remove(blog.id);
        setBlogs(blogs.filter((b) => b.id !== blog.id));
      } catch (exception) {
        console.error("Error deleting blog:", exception);
      }
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { style: blogStyle, className: "blog", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "blog-title", children: [
      blog.title,
      " ",
      blog.author,
      " ",
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleDetails, children: detailsVisible ? "hide" : "view" }, void 0, false, {
        fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 44,
        columnNumber: 36
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 43,
      columnNumber: 7
    }, this),
    detailsVisible && /* @__PURE__ */ jsxDEV("div", { className: "blog-details", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "blog-url", children: blog.url }, void 0, false, {
        fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 47,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "blog-likes", children: [
        blog.likes,
        " likes ",
        /* @__PURE__ */ jsxDEV("button", { onClick: handleLike, children: "like" }, void 0, false, {
          fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Blog.jsx",
          lineNumber: 49,
          columnNumber: 32
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 48,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "added by ",
        blog.user?.name || "Unknown"
      ] }, void 0, true, {
        fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 51,
        columnNumber: 11
      }, this),
      user && blog.user && blog.user.username === user.username && /* @__PURE__ */ jsxDEV("button", { onClick: handleDelete, children: "remove" }, void 0, false, {
        fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 52,
        columnNumber: 73
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 46,
      columnNumber: 26
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Blog.jsx",
    lineNumber: 42,
    columnNumber: 10
  }, this);
};
_s(Blog, "Hh5inoR7FNss1DRgdhm4+KI+HsY=");
_c = Blog;
Blog.propTypes = {
  blog: PropTypes.shape({
    id: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
    author: PropTypes.string.isRequired,
    url: PropTypes.string.isRequired,
    likes: PropTypes.number.isRequired,
    user: PropTypes.shape({
      username: PropTypes.string.isRequired,
      name: PropTypes.string.isRequired
    })
  }).isRequired,
  user: PropTypes.shape({
    username: PropTypes.string.isRequired
  }),
  setBlogs: PropTypes.func.isRequired,
  blogs: PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.string.isRequired
  })).isRequired
};
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMENtQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUExQ25DLE9BQU9BLFNBQVNDLGdCQUFnQjtBQUNoQyxPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0MsZUFBZTtBQUV0QixNQUFNQyxPQUFPQSxDQUFDO0FBQUEsRUFBRUM7QUFBQUEsRUFBTUM7QUFBQUEsRUFBTUM7QUFBQUEsRUFBVUM7QUFBQUEsRUFBT0M7QUFBVyxNQUFNO0FBQUFDLEtBQUE7QUFDNUQsUUFBTSxDQUFDQyxnQkFBZ0JDLGlCQUFpQixJQUFJWCxTQUFTLEtBQUs7QUFFMUQsUUFBTVksWUFBWTtBQUFBLElBQ2hCQyxZQUFZO0FBQUEsSUFDWkMsYUFBYTtBQUFBLElBQ2JDLFFBQVE7QUFBQSxJQUNSQyxhQUFhO0FBQUEsSUFDYkMsY0FBYztBQUFBLEVBQ2hCO0FBRUEsUUFBTUMsZ0JBQWdCQSxNQUFNO0FBQzFCUCxzQkFBa0IsQ0FBQ0QsY0FBYztBQUFBLEVBQ25DO0FBRUEsUUFBTVMsYUFBYSxZQUFZO0FBQzdCLFVBQU1DLGNBQWM7QUFBQSxNQUNsQixHQUFHaEI7QUFBQUEsTUFDSGlCLE9BQU9qQixLQUFLaUIsUUFBUTtBQUFBLElBQ3RCO0FBQ0EsVUFBTXBCLFlBQVlxQixPQUFPbEIsS0FBS21CLElBQUlILFdBQVc7QUFDN0NaLGVBQVdKLEtBQUttQixJQUFJSCxXQUFXO0FBQUEsRUFDakM7QUFFQSxRQUFNSSxlQUFlLFlBQVk7QUFDL0IsUUFBSUMsT0FBT0MsUUFBUyxnQkFBZXRCLEtBQUt1QixLQUFNLFFBQU92QixLQUFLd0IsTUFBTyxHQUFFLEdBQUc7QUFDcEUsVUFBSTtBQUNGLGNBQU0zQixZQUFZNEIsT0FBT3pCLEtBQUttQixFQUFFO0FBQ2hDakIsaUJBQVNDLE1BQU11QixPQUFPQyxPQUFLQSxFQUFFUixPQUFPbkIsS0FBS21CLEVBQUUsQ0FBQztBQUFBLE1BQzlDLFNBQVNTLFdBQVc7QUFDbEJDLGdCQUFRQyxNQUFNLHdCQUF3QkYsU0FBUztBQUFBLE1BQ2pEO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksT0FBT3BCLFdBQVcsV0FBVSxRQUMvQjtBQUFBLDJCQUFDLFNBQUksV0FBVSxjQUNaUjtBQUFBQSxXQUFLdUI7QUFBQUEsTUFBTTtBQUFBLE1BQUV2QixLQUFLd0I7QUFBQUEsTUFBTztBQUFBLE1BQUMsdUJBQUMsWUFBTyxTQUFTVixlQUFnQlIsMkJBQWlCLFNBQVMsVUFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRTtBQUFBLFNBRC9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0NBLGtCQUNDLHVCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxZQUFZTixlQUFLK0IsT0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQztBQUFBLE1BQ3BDLHVCQUFDLFNBQUksV0FBVSxjQUNaL0I7QUFBQUEsYUFBS2lCO0FBQUFBLFFBQU07QUFBQSxRQUFPLHVCQUFDLFlBQU8sU0FBU0YsWUFBWSxvQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQztBQUFBLFdBRHREO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSTtBQUFBO0FBQUEsUUFBVWYsS0FBS0MsTUFBTStCLFFBQVE7QUFBQSxXQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRDO0FBQUEsTUFDM0MvQixRQUFRRCxLQUFLQyxRQUFRRCxLQUFLQyxLQUFLZ0MsYUFBYWhDLEtBQUtnQyxZQUNoRCx1QkFBQyxZQUFPLFNBQVNiLGNBQWMsc0JBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUM7QUFBQSxTQVB6QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxPQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQkE7QUFFSjtBQUFDZixHQXRES04sTUFBSTtBQUFBbUMsS0FBSm5DO0FBd0ROQSxLQUFLb0MsWUFBWTtBQUFBLEVBQ2ZuQyxNQUFNRixVQUFVc0MsTUFBTTtBQUFBLElBQ3BCakIsSUFBSXJCLFVBQVV1QyxPQUFPQztBQUFBQSxJQUNyQmYsT0FBT3pCLFVBQVV1QyxPQUFPQztBQUFBQSxJQUN4QmQsUUFBUTFCLFVBQVV1QyxPQUFPQztBQUFBQSxJQUN6QlAsS0FBS2pDLFVBQVV1QyxPQUFPQztBQUFBQSxJQUN0QnJCLE9BQU9uQixVQUFVeUMsT0FBT0Q7QUFBQUEsSUFDeEJyQyxNQUFNSCxVQUFVc0MsTUFBTTtBQUFBLE1BQ3BCSCxVQUFVbkMsVUFBVXVDLE9BQU9DO0FBQUFBLE1BQzNCTixNQUFNbEMsVUFBVXVDLE9BQU9DO0FBQUFBLElBQ3pCLENBQUM7QUFBQSxFQUNILENBQUMsRUFBRUE7QUFBQUEsRUFDSHJDLE1BQU1ILFVBQVVzQyxNQUFNO0FBQUEsSUFDcEJILFVBQVVuQyxVQUFVdUMsT0FBT0M7QUFBQUEsRUFDN0IsQ0FBQztBQUFBLEVBQ0RwQyxVQUFVSixVQUFVMEMsS0FBS0Y7QUFBQUEsRUFDekJuQyxPQUFPTCxVQUFVMkMsUUFDZjNDLFVBQVVzQyxNQUFNO0FBQUEsSUFDZGpCLElBQUlyQixVQUFVdUMsT0FBT0M7QUFBQUEsRUFDdkIsQ0FBQyxDQUNILEVBQUVBO0FBQ0o7QUFFQSxlQUFldkM7QUFBSSxJQUFBbUM7QUFBQVEsYUFBQVIsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJibG9nU2VydmljZSIsIlByb3BUeXBlcyIsIkJsb2ciLCJibG9nIiwidXNlciIsInNldEJsb2dzIiwiYmxvZ3MiLCJ1cGRhdGVCbG9nIiwiX3MiLCJkZXRhaWxzVmlzaWJsZSIsInNldERldGFpbHNWaXNpYmxlIiwiYmxvZ1N0eWxlIiwicGFkZGluZ1RvcCIsInBhZGRpbmdMZWZ0IiwiYm9yZGVyIiwiYm9yZGVyV2lkdGgiLCJtYXJnaW5Cb3R0b20iLCJ0b2dnbGVEZXRhaWxzIiwiaGFuZGxlTGlrZSIsInVwZGF0ZWRCbG9nIiwibGlrZXMiLCJ1cGRhdGUiLCJpZCIsImhhbmRsZURlbGV0ZSIsIndpbmRvdyIsImNvbmZpcm0iLCJ0aXRsZSIsImF1dGhvciIsInJlbW92ZSIsImZpbHRlciIsImIiLCJleGNlcHRpb24iLCJjb25zb2xlIiwiZXJyb3IiLCJ1cmwiLCJuYW1lIiwidXNlcm5hbWUiLCJfYyIsInByb3BUeXBlcyIsInNoYXBlIiwic3RyaW5nIiwiaXNSZXF1aXJlZCIsIm51bWJlciIsImZ1bmMiLCJhcnJheU9mIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQmxvZy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgYmxvZ1NlcnZpY2UgZnJvbSAnLi4vc2VydmljZXMvYmxvZ3MnXG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnXG5cbmNvbnN0IEJsb2cgPSAoeyBibG9nLCB1c2VyLCBzZXRCbG9ncywgYmxvZ3MsIHVwZGF0ZUJsb2cgfSkgPT4ge1xuICBjb25zdCBbZGV0YWlsc1Zpc2libGUsIHNldERldGFpbHNWaXNpYmxlXSA9IHVzZVN0YXRlKGZhbHNlKVxuXG4gIGNvbnN0IGJsb2dTdHlsZSA9IHtcbiAgICBwYWRkaW5nVG9wOiAxMCxcbiAgICBwYWRkaW5nTGVmdDogMixcbiAgICBib3JkZXI6ICdzb2xpZCcsXG4gICAgYm9yZGVyV2lkdGg6IDEsXG4gICAgbWFyZ2luQm90dG9tOiA1LFxuICB9XG5cbiAgY29uc3QgdG9nZ2xlRGV0YWlscyA9ICgpID0+IHtcbiAgICBzZXREZXRhaWxzVmlzaWJsZSghZGV0YWlsc1Zpc2libGUpXG4gIH1cblxuICBjb25zdCBoYW5kbGVMaWtlID0gYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHVwZGF0ZWRCbG9nID0ge1xuICAgICAgLi4uYmxvZyxcbiAgICAgIGxpa2VzOiBibG9nLmxpa2VzICsgMSxcbiAgICB9XG4gICAgYXdhaXQgYmxvZ1NlcnZpY2UudXBkYXRlKGJsb2cuaWQsIHVwZGF0ZWRCbG9nKVxuICAgIHVwZGF0ZUJsb2coYmxvZy5pZCwgdXBkYXRlZEJsb2cpXG4gIH1cblxuICBjb25zdCBoYW5kbGVEZWxldGUgPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKHdpbmRvdy5jb25maXJtKGBSZW1vdmUgYmxvZyBcIiR7YmxvZy50aXRsZX1cIiBieSAke2Jsb2cuYXV0aG9yfT9gKSkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgYmxvZ1NlcnZpY2UucmVtb3ZlKGJsb2cuaWQpXG4gICAgICAgIHNldEJsb2dzKGJsb2dzLmZpbHRlcihiID0+IGIuaWQgIT09IGJsb2cuaWQpKVxuICAgICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGRlbGV0aW5nIGJsb2c6JywgZXhjZXB0aW9uKVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBzdHlsZT17YmxvZ1N0eWxlfSBjbGFzc05hbWU9XCJibG9nXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT0nYmxvZy10aXRsZSc+XG4gICAgICAgIHtibG9nLnRpdGxlfSB7YmxvZy5hdXRob3J9IDxidXR0b24gb25DbGljaz17dG9nZ2xlRGV0YWlsc30+e2RldGFpbHNWaXNpYmxlID8gJ2hpZGUnIDogJ3ZpZXcnfTwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgICB7ZGV0YWlsc1Zpc2libGUgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJsb2ctZGV0YWlsc1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmxvZy11cmxcIj57YmxvZy51cmx9PC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJibG9nLWxpa2VzXCI+XG4gICAgICAgICAgICB7YmxvZy5saWtlc30gbGlrZXMgPGJ1dHRvbiBvbkNsaWNrPXtoYW5kbGVMaWtlfT5saWtlPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdj5hZGRlZCBieSB7YmxvZy51c2VyPy5uYW1lIHx8ICdVbmtub3duJ308L2Rpdj5cbiAgICAgICAgICB7dXNlciAmJiBibG9nLnVzZXIgJiYgYmxvZy51c2VyLnVzZXJuYW1lID09PSB1c2VyLnVzZXJuYW1lICYmIChcbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17aGFuZGxlRGVsZXRlfT5yZW1vdmU8L2J1dHRvbj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gIClcbn1cblxuQmxvZy5wcm9wVHlwZXMgPSB7XG4gIGJsb2c6IFByb3BUeXBlcy5zaGFwZSh7XG4gICAgaWQ6IFByb3BUeXBlcy5zdHJpbmcuaXNSZXF1aXJlZCxcbiAgICB0aXRsZTogUHJvcFR5cGVzLnN0cmluZy5pc1JlcXVpcmVkLFxuICAgIGF1dGhvcjogUHJvcFR5cGVzLnN0cmluZy5pc1JlcXVpcmVkLFxuICAgIHVybDogUHJvcFR5cGVzLnN0cmluZy5pc1JlcXVpcmVkLFxuICAgIGxpa2VzOiBQcm9wVHlwZXMubnVtYmVyLmlzUmVxdWlyZWQsXG4gICAgdXNlcjogUHJvcFR5cGVzLnNoYXBlKHtcbiAgICAgIHVzZXJuYW1lOiBQcm9wVHlwZXMuc3RyaW5nLmlzUmVxdWlyZWQsXG4gICAgICBuYW1lOiBQcm9wVHlwZXMuc3RyaW5nLmlzUmVxdWlyZWQsXG4gICAgfSksXG4gIH0pLmlzUmVxdWlyZWQsXG4gIHVzZXI6IFByb3BUeXBlcy5zaGFwZSh7XG4gICAgdXNlcm5hbWU6IFByb3BUeXBlcy5zdHJpbmcuaXNSZXF1aXJlZCxcbiAgfSksXG4gIHNldEJsb2dzOiBQcm9wVHlwZXMuZnVuYy5pc1JlcXVpcmVkLFxuICBibG9nczogUHJvcFR5cGVzLmFycmF5T2YoXG4gICAgUHJvcFR5cGVzLnNoYXBlKHtcbiAgICAgIGlkOiBQcm9wVHlwZXMuc3RyaW5nLmlzUmVxdWlyZWQsXG4gICAgfSlcbiAgKS5pc1JlcXVpcmVkLFxufVxuXG5leHBvcnQgZGVmYXVsdCBCbG9nIl0sImZpbGUiOiIvVXNlcnMvYW50b25kZW1pbi9SZWFjdFByb2plY3RzL0Z1bGxTdGFja0NvdXJzZS9QYXJ0NS9ibG9nbGlzdC1mcm9udGVuZC9zcmMvY29tcG9uZW50cy9CbG9nLmpzeCJ9