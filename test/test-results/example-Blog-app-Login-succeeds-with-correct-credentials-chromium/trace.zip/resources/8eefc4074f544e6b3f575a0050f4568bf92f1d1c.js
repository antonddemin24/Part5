import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0a8c374f"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Blog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=0a8c374f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import blogService from "/src/services/blogs.js";
import __vite__cjsImport5_propTypes from "/node_modules/.vite/deps/prop-types.js?v=0a8c374f"; const PropTypes = __vite__cjsImport5_propTypes.__esModule ? __vite__cjsImport5_propTypes.default : __vite__cjsImport5_propTypes;
const Blog = ({
  blog,
  user,
  setBlogs,
  blogs,
  updateBlog
}) => {
  _s();
  const [detailsVisible, setDetailsVisible] = useState(false);
  const blogStyle = {
    paddingTop: 10,
    paddingLeft: 2,
    border: "solid",
    borderWidth: 1,
    marginBottom: 5
  };
  const toggleDetails = () => {
    setDetailsVisible(!detailsVisible);
  };
  const handleLike = async () => {
    const updatedBlog = {
      ...blog,
      likes: blog.likes + 1
    };
    await blogService.update(blog.id, updatedBlog);
    updateBlog(blog.id, updatedBlog);
  };
  const handleDelete = async () => {
    if (window.confirm(`Remove blog "${blog.title}" by ${blog.author}?`)) {
      try {
        await blogService.remove(blog.id);
        setBlogs(blogs.filter((b) => b.id !== blog.id));
      } catch (exception) {
        console.error("Error deleting blog:", exception);
      }
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { style: blogStyle, className: "blog", children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      blog.title,
      " ",
      blog.author,
      " ",
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleDetails, children: detailsVisible ? "hide" : "view" }, void 0, false, {
        fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 44,
        columnNumber: 36
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 43,
      columnNumber: 7
    }, this),
    detailsVisible && /* @__PURE__ */ jsxDEV("div", { className: "blog-details", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "blog-url", children: blog.url }, void 0, false, {
        fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 47,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "blog-likes", children: [
        blog.likes,
        " likes ",
        /* @__PURE__ */ jsxDEV("button", { onClick: handleLike, children: "like" }, void 0, false, {
          fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Blog.jsx",
          lineNumber: 49,
          columnNumber: 32
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 48,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "added by ",
        blog.user?.name || "Unknown"
      ] }, void 0, true, {
        fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 51,
        columnNumber: 11
      }, this),
      user && blog.user && blog.user.username === user.username && /* @__PURE__ */ jsxDEV("button", { onClick: handleDelete, children: "remove" }, void 0, false, {
        fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 52,
        columnNumber: 73
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 46,
      columnNumber: 26
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Blog.jsx",
    lineNumber: 42,
    columnNumber: 10
  }, this);
};
_s(Blog, "Hh5inoR7FNss1DRgdhm4+KI+HsY=");
_c = Blog;
Blog.propTypes = {
  blog: PropTypes.shape({
    id: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
    author: PropTypes.string.isRequired,
    url: PropTypes.string.isRequired,
    likes: PropTypes.number.isRequired,
    user: PropTypes.shape({
      username: PropTypes.string.isRequired,
      name: PropTypes.string.isRequired
    })
  }).isRequired,
  user: PropTypes.shape({
    username: PropTypes.string.isRequired
  }),
  setBlogs: PropTypes.func.isRequired,
  blogs: PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.string.isRequired
  })).isRequired
};
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMENtQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUExQ25DLE9BQU9BLFNBQVNDLGdCQUFnQjtBQUNoQyxPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0MsZUFBZTtBQUV0QixNQUFNQyxPQUFPQSxDQUFDO0FBQUEsRUFBRUM7QUFBQUEsRUFBTUM7QUFBQUEsRUFBTUM7QUFBQUEsRUFBVUM7QUFBQUEsRUFBT0M7QUFBVyxNQUFNO0FBQUFDLEtBQUE7QUFDNUQsUUFBTSxDQUFDQyxnQkFBZ0JDLGlCQUFpQixJQUFJWCxTQUFTLEtBQUs7QUFFMUQsUUFBTVksWUFBWTtBQUFBLElBQ2hCQyxZQUFZO0FBQUEsSUFDWkMsYUFBYTtBQUFBLElBQ2JDLFFBQVE7QUFBQSxJQUNSQyxhQUFhO0FBQUEsSUFDYkMsY0FBYztBQUFBLEVBQ2hCO0FBRUEsUUFBTUMsZ0JBQWdCQSxNQUFNO0FBQzFCUCxzQkFBa0IsQ0FBQ0QsY0FBYztBQUFBLEVBQ25DO0FBRUEsUUFBTVMsYUFBYSxZQUFZO0FBQzdCLFVBQU1DLGNBQWM7QUFBQSxNQUNsQixHQUFHaEI7QUFBQUEsTUFDSGlCLE9BQU9qQixLQUFLaUIsUUFBUTtBQUFBLElBQ3RCO0FBQ0EsVUFBTXBCLFlBQVlxQixPQUFPbEIsS0FBS21CLElBQUlILFdBQVc7QUFDN0NaLGVBQVdKLEtBQUttQixJQUFJSCxXQUFXO0FBQUEsRUFDakM7QUFFQSxRQUFNSSxlQUFlLFlBQVk7QUFDL0IsUUFBSUMsT0FBT0MsUUFBUyxnQkFBZXRCLEtBQUt1QixLQUFNLFFBQU92QixLQUFLd0IsTUFBTyxHQUFFLEdBQUc7QUFDcEUsVUFBSTtBQUNGLGNBQU0zQixZQUFZNEIsT0FBT3pCLEtBQUttQixFQUFFO0FBQ2hDakIsaUJBQVNDLE1BQU11QixPQUFPQyxPQUFLQSxFQUFFUixPQUFPbkIsS0FBS21CLEVBQUUsQ0FBQztBQUFBLE1BQzlDLFNBQVNTLFdBQVc7QUFDbEJDLGdCQUFRQyxNQUFNLHdCQUF3QkYsU0FBUztBQUFBLE1BQ2pEO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksT0FBT3BCLFdBQVcsV0FBVSxRQUMvQjtBQUFBLDJCQUFDLFNBQ0VSO0FBQUFBLFdBQUt1QjtBQUFBQSxNQUFNO0FBQUEsTUFBRXZCLEtBQUt3QjtBQUFBQSxNQUFPO0FBQUEsTUFBQyx1QkFBQyxZQUFPLFNBQVNWLGVBQWdCUiwyQkFBaUIsU0FBUyxVQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtFO0FBQUEsU0FEL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQ0Esa0JBQ0MsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLFlBQVlOLGVBQUsrQixPQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9DO0FBQUEsTUFDcEMsdUJBQUMsU0FBSSxXQUFVLGNBQ1ovQjtBQUFBQSxhQUFLaUI7QUFBQUEsUUFBTTtBQUFBLFFBQU8sdUJBQUMsWUFBTyxTQUFTRixZQUFZLG9CQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlDO0FBQUEsV0FEdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJO0FBQUE7QUFBQSxRQUFVZixLQUFLQyxNQUFNK0IsUUFBUTtBQUFBLFdBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEM7QUFBQSxNQUMzQy9CLFFBQVFELEtBQUtDLFFBQVFELEtBQUtDLEtBQUtnQyxhQUFhaEMsS0FBS2dDLFlBQ2hELHVCQUFDLFlBQU8sU0FBU2IsY0FBYyxzQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxQztBQUFBLFNBUHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLE9BZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdCQTtBQUVKO0FBQUNmLEdBdERLTixNQUFJO0FBQUFtQyxLQUFKbkM7QUF3RE5BLEtBQUtvQyxZQUFZO0FBQUEsRUFDZm5DLE1BQU1GLFVBQVVzQyxNQUFNO0FBQUEsSUFDcEJqQixJQUFJckIsVUFBVXVDLE9BQU9DO0FBQUFBLElBQ3JCZixPQUFPekIsVUFBVXVDLE9BQU9DO0FBQUFBLElBQ3hCZCxRQUFRMUIsVUFBVXVDLE9BQU9DO0FBQUFBLElBQ3pCUCxLQUFLakMsVUFBVXVDLE9BQU9DO0FBQUFBLElBQ3RCckIsT0FBT25CLFVBQVV5QyxPQUFPRDtBQUFBQSxJQUN4QnJDLE1BQU1ILFVBQVVzQyxNQUFNO0FBQUEsTUFDcEJILFVBQVVuQyxVQUFVdUMsT0FBT0M7QUFBQUEsTUFDM0JOLE1BQU1sQyxVQUFVdUMsT0FBT0M7QUFBQUEsSUFDekIsQ0FBQztBQUFBLEVBQ0gsQ0FBQyxFQUFFQTtBQUFBQSxFQUNIckMsTUFBTUgsVUFBVXNDLE1BQU07QUFBQSxJQUNwQkgsVUFBVW5DLFVBQVV1QyxPQUFPQztBQUFBQSxFQUM3QixDQUFDO0FBQUEsRUFDRHBDLFVBQVVKLFVBQVUwQyxLQUFLRjtBQUFBQSxFQUN6Qm5DLE9BQU9MLFVBQVUyQyxRQUNmM0MsVUFBVXNDLE1BQU07QUFBQSxJQUNkakIsSUFBSXJCLFVBQVV1QyxPQUFPQztBQUFBQSxFQUN2QixDQUFDLENBQ0gsRUFBRUE7QUFDSjtBQUVBLGVBQWV2QztBQUFJLElBQUFtQztBQUFBUSxhQUFBUixJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VTdGF0ZSIsImJsb2dTZXJ2aWNlIiwiUHJvcFR5cGVzIiwiQmxvZyIsImJsb2ciLCJ1c2VyIiwic2V0QmxvZ3MiLCJibG9ncyIsInVwZGF0ZUJsb2ciLCJfcyIsImRldGFpbHNWaXNpYmxlIiwic2V0RGV0YWlsc1Zpc2libGUiLCJibG9nU3R5bGUiLCJwYWRkaW5nVG9wIiwicGFkZGluZ0xlZnQiLCJib3JkZXIiLCJib3JkZXJXaWR0aCIsIm1hcmdpbkJvdHRvbSIsInRvZ2dsZURldGFpbHMiLCJoYW5kbGVMaWtlIiwidXBkYXRlZEJsb2ciLCJsaWtlcyIsInVwZGF0ZSIsImlkIiwiaGFuZGxlRGVsZXRlIiwid2luZG93IiwiY29uZmlybSIsInRpdGxlIiwiYXV0aG9yIiwicmVtb3ZlIiwiZmlsdGVyIiwiYiIsImV4Y2VwdGlvbiIsImNvbnNvbGUiLCJlcnJvciIsInVybCIsIm5hbWUiLCJ1c2VybmFtZSIsIl9jIiwicHJvcFR5cGVzIiwic2hhcGUiLCJzdHJpbmciLCJpc1JlcXVpcmVkIiwibnVtYmVyIiwiZnVuYyIsImFycmF5T2YiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJCbG9nLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCBibG9nU2VydmljZSBmcm9tICcuLi9zZXJ2aWNlcy9ibG9ncydcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcydcblxuY29uc3QgQmxvZyA9ICh7IGJsb2csIHVzZXIsIHNldEJsb2dzLCBibG9ncywgdXBkYXRlQmxvZyB9KSA9PiB7XG4gIGNvbnN0IFtkZXRhaWxzVmlzaWJsZSwgc2V0RGV0YWlsc1Zpc2libGVdID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgY29uc3QgYmxvZ1N0eWxlID0ge1xuICAgIHBhZGRpbmdUb3A6IDEwLFxuICAgIHBhZGRpbmdMZWZ0OiAyLFxuICAgIGJvcmRlcjogJ3NvbGlkJyxcbiAgICBib3JkZXJXaWR0aDogMSxcbiAgICBtYXJnaW5Cb3R0b206IDUsXG4gIH1cblxuICBjb25zdCB0b2dnbGVEZXRhaWxzID0gKCkgPT4ge1xuICAgIHNldERldGFpbHNWaXNpYmxlKCFkZXRhaWxzVmlzaWJsZSlcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUxpa2UgPSBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgdXBkYXRlZEJsb2cgPSB7XG4gICAgICAuLi5ibG9nLFxuICAgICAgbGlrZXM6IGJsb2cubGlrZXMgKyAxLFxuICAgIH1cbiAgICBhd2FpdCBibG9nU2VydmljZS51cGRhdGUoYmxvZy5pZCwgdXBkYXRlZEJsb2cpXG4gICAgdXBkYXRlQmxvZyhibG9nLmlkLCB1cGRhdGVkQmxvZylcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZURlbGV0ZSA9IGFzeW5jICgpID0+IHtcbiAgICBpZiAod2luZG93LmNvbmZpcm0oYFJlbW92ZSBibG9nIFwiJHtibG9nLnRpdGxlfVwiIGJ5ICR7YmxvZy5hdXRob3J9P2ApKSB7XG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCBibG9nU2VydmljZS5yZW1vdmUoYmxvZy5pZClcbiAgICAgICAgc2V0QmxvZ3MoYmxvZ3MuZmlsdGVyKGIgPT4gYi5pZCAhPT0gYmxvZy5pZCkpXG4gICAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgZGVsZXRpbmcgYmxvZzonLCBleGNlcHRpb24pXG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IHN0eWxlPXtibG9nU3R5bGV9IGNsYXNzTmFtZT1cImJsb2dcIj5cbiAgICAgIDxkaXY+XG4gICAgICAgIHtibG9nLnRpdGxlfSB7YmxvZy5hdXRob3J9IDxidXR0b24gb25DbGljaz17dG9nZ2xlRGV0YWlsc30+e2RldGFpbHNWaXNpYmxlID8gJ2hpZGUnIDogJ3ZpZXcnfTwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgICB7ZGV0YWlsc1Zpc2libGUgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJsb2ctZGV0YWlsc1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmxvZy11cmxcIj57YmxvZy51cmx9PC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJibG9nLWxpa2VzXCI+XG4gICAgICAgICAgICB7YmxvZy5saWtlc30gbGlrZXMgPGJ1dHRvbiBvbkNsaWNrPXtoYW5kbGVMaWtlfT5saWtlPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdj5hZGRlZCBieSB7YmxvZy51c2VyPy5uYW1lIHx8ICdVbmtub3duJ308L2Rpdj5cbiAgICAgICAgICB7dXNlciAmJiBibG9nLnVzZXIgJiYgYmxvZy51c2VyLnVzZXJuYW1lID09PSB1c2VyLnVzZXJuYW1lICYmIChcbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17aGFuZGxlRGVsZXRlfT5yZW1vdmU8L2J1dHRvbj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gIClcbn1cblxuQmxvZy5wcm9wVHlwZXMgPSB7XG4gIGJsb2c6IFByb3BUeXBlcy5zaGFwZSh7XG4gICAgaWQ6IFByb3BUeXBlcy5zdHJpbmcuaXNSZXF1aXJlZCxcbiAgICB0aXRsZTogUHJvcFR5cGVzLnN0cmluZy5pc1JlcXVpcmVkLFxuICAgIGF1dGhvcjogUHJvcFR5cGVzLnN0cmluZy5pc1JlcXVpcmVkLFxuICAgIHVybDogUHJvcFR5cGVzLnN0cmluZy5pc1JlcXVpcmVkLFxuICAgIGxpa2VzOiBQcm9wVHlwZXMubnVtYmVyLmlzUmVxdWlyZWQsXG4gICAgdXNlcjogUHJvcFR5cGVzLnNoYXBlKHtcbiAgICAgIHVzZXJuYW1lOiBQcm9wVHlwZXMuc3RyaW5nLmlzUmVxdWlyZWQsXG4gICAgICBuYW1lOiBQcm9wVHlwZXMuc3RyaW5nLmlzUmVxdWlyZWQsXG4gICAgfSksXG4gIH0pLmlzUmVxdWlyZWQsXG4gIHVzZXI6IFByb3BUeXBlcy5zaGFwZSh7XG4gICAgdXNlcm5hbWU6IFByb3BUeXBlcy5zdHJpbmcuaXNSZXF1aXJlZCxcbiAgfSksXG4gIHNldEJsb2dzOiBQcm9wVHlwZXMuZnVuYy5pc1JlcXVpcmVkLFxuICBibG9nczogUHJvcFR5cGVzLmFycmF5T2YoXG4gICAgUHJvcFR5cGVzLnNoYXBlKHtcbiAgICAgIGlkOiBQcm9wVHlwZXMuc3RyaW5nLmlzUmVxdWlyZWQsXG4gICAgfSlcbiAgKS5pc1JlcXVpcmVkLFxufVxuXG5leHBvcnQgZGVmYXVsdCBCbG9nIl0sImZpbGUiOiIvVXNlcnMvYW50b25kZW1pbi9SZWFjdFByb2plY3RzL0Z1bGxTdGFja0NvdXJzZS9QYXJ0NS9ibG9nbGlzdC1mcm9udGVuZC9zcmMvY29tcG9uZW50cy9CbG9nLmpzeCJ9