import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0a8c374f"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=0a8c374f"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import Blog from "/src/components/Blog.jsx?t=1720072598229";
import BlogForm from "/src/components/BlogForm.jsx?t=1720054941939";
import Togglable from "/src/components/Togglable.jsx";
import blogService from "/src/services/blogs.js";
import loginService from "/src/services/login.js";
const Notification = ({
  message,
  type
}) => {
  const notificationStyle = {
    color: type === "error" ? "red" : "green",
    background: "lightgrey",
    fontSize: "20px",
    borderStyle: "solid",
    borderRadius: "5px",
    padding: "10px",
    marginBottom: "10px"
  };
  if (message === null) {
    return null;
  }
  return /* @__PURE__ */ jsxDEV("div", { style: notificationStyle, children: message }, void 0, false, {
    fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/App.jsx",
    lineNumber: 24,
    columnNumber: 10
  }, this);
};
_c = Notification;
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  const [errorMessage, setErrorMessage] = useState(null);
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [url, setUrl] = useState("");
  const [notification, setNotification] = useState({
    message: null,
    type: null
  });
  const blogFormRef = useRef();
  useEffect(() => {
    const loggedUserJSON = window.localStorage.getItem("loggedBlogAppUser");
    if (loggedUserJSON) {
      const user2 = JSON.parse(loggedUserJSON);
      setUser(user2);
      blogService.setToken(user2.token);
      const fetchBlogs = async () => {
        try {
          const fetchedBlogs = await blogService.getAll();
          setBlogs(fetchedBlogs);
        } catch (error) {
          console.error("Error fetching blogs:", error);
          setNotification({
            message: "Error fetching blogs",
            type: "error"
          });
        }
      };
      fetchBlogs();
    }
  }, []);
  const handleLogin = async (event) => {
    event.preventDefault();
    try {
      const user2 = await loginService.login({
        username,
        password
      });
      window.localStorage.setItem("loggedBlogAppUser", JSON.stringify(user2));
      blogService.setToken(user2.token);
      setUser(user2);
      setUsername("");
      setPassword("");
      const fetchedBlogs = await blogService.getAll();
      setBlogs(fetchedBlogs);
    } catch (exception) {
      setNotification({
        message: "Wrong credentials",
        type: "error"
      });
      setTimeout(() => {
        setNotification({
          message: null,
          type: null
        });
      }, 5e3);
    }
  };
  const handleLogout = () => {
    window.localStorage.removeItem("loggedBlogAppUser");
    setUser(null);
    blogService.setToken(null);
    setNotification({
      message: "Logged out successfully",
      type: "success"
    });
    setTimeout(() => {
      setNotification({
        message: null,
        type: null
      });
    }, 5e3);
  };
  const addBlog = async (blogObject) => {
    try {
      const returnedBlog = await blogService.create(blogObject);
      const fetchedBlogs = await blogService.getAll();
      setBlogs(fetchedBlogs);
      blogFormRef.current.toggleVisibility();
      setNotification({
        message: `Added new blog: ${returnedBlog.title} by ${returnedBlog.author}`,
        type: "success"
      });
      setTimeout(() => {
        setNotification({
          message: null,
          type: null
        });
      }, 5e3);
    } catch (error) {
      setNotification({
        message: "Failed to add blog",
        type: "error"
      });
      setTimeout(() => {
        setNotification({
          message: null,
          type: null
        });
      }, 5e3);
    }
  };
  const updateBlog = (id, updatedBlog) => {
    setBlogs(blogs.map((blog) => blog.id === id ? updatedBlog : blog));
  };
  const loginForm = () => /* @__PURE__ */ jsxDEV("form", { onSubmit: handleLogin, children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      "Username",
      /* @__PURE__ */ jsxDEV("input", { type: "text", value: username, name: "Username", onChange: ({
        target
      }) => setUsername(target.value) }, void 0, false, {
        fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/App.jsx",
        lineNumber: 143,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/App.jsx",
      lineNumber: 141,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      "Password",
      /* @__PURE__ */ jsxDEV("input", { type: "password", value: password, name: "Password", onChange: ({
        target
      }) => setPassword(target.value) }, void 0, false, {
        fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/App.jsx",
        lineNumber: 149,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/App.jsx",
      lineNumber: 147,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "login" }, void 0, false, {
      fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/App.jsx",
      lineNumber: 153,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/App.jsx",
    lineNumber: 140,
    columnNumber: 27
  }, this);
  const sortedBlogs = blogs.sort((a, b) => b.likes - a.likes);
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Blogs" }, void 0, false, {
      fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/App.jsx",
      lineNumber: 157,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Notification, { message: notification.message, type: notification.type }, void 0, false, {
      fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/App.jsx",
      lineNumber: 158,
      columnNumber: 7
    }, this),
    user === null ? /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h2", { children: "Log in to application" }, void 0, false, {
        fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/App.jsx",
        lineNumber: 160,
        columnNumber: 11
      }, this),
      loginForm()
    ] }, void 0, true, {
      fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/App.jsx",
      lineNumber: 159,
      columnNumber: 24
    }, this) : /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("p", { children: [
        "Welcome, ",
        user.name,
        "!",
        " ",
        /* @__PURE__ */ jsxDEV("button", { onClick: handleLogout, children: "Logout" }, void 0, false, {
          fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/App.jsx",
          lineNumber: 165,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/App.jsx",
        lineNumber: 163,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "New Blog", ref: blogFormRef, children: /* @__PURE__ */ jsxDEV(BlogForm, { createBlog: addBlog }, void 0, false, {
        fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/App.jsx",
        lineNumber: 168,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/App.jsx",
        lineNumber: 167,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "blog-list", children: sortedBlogs.map((blog) => /* @__PURE__ */ jsxDEV(Blog, { blog, user, setBlogs, blogs, updateBlog }, blog.id, false, {
        fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/App.jsx",
        lineNumber: 171,
        columnNumber: 38
      }, this)) }, void 0, false, {
        fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/App.jsx",
        lineNumber: 170,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/App.jsx",
      lineNumber: 162,
      columnNumber: 18
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/App.jsx",
    lineNumber: 156,
    columnNumber: 10
  }, this);
};
_s(App, "ACGC1ehCecpdrtNrfNGXht87Sdc=");
_c2 = App;
export default App;
var _c, _c2;
$RefreshReg$(_c, "Notification");
$RefreshReg$(_c2, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUJTOzs7Ozs7Ozs7Ozs7Ozs7OztBQXZCVCxTQUFTQSxVQUFVQyxXQUFXQyxjQUFjO0FBQzVDLE9BQU9DLFVBQVU7QUFDakIsT0FBT0MsY0FBYztBQUNyQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxrQkFBa0I7QUFHekIsTUFBTUMsZUFBZUEsQ0FBQztBQUFBLEVBQUVDO0FBQUFBLEVBQVNDO0FBQUssTUFBTTtBQUMxQyxRQUFNQyxvQkFBb0I7QUFBQSxJQUN4QkMsT0FBT0YsU0FBUyxVQUFVLFFBQVE7QUFBQSxJQUNsQ0csWUFBWTtBQUFBLElBQ1pDLFVBQVU7QUFBQSxJQUNWQyxhQUFhO0FBQUEsSUFDYkMsY0FBYztBQUFBLElBQ2RDLFNBQVM7QUFBQSxJQUNUQyxjQUFjO0FBQUEsRUFDaEI7QUFFQSxNQUFJVCxZQUFZLE1BQU07QUFDcEIsV0FBTztBQUFBLEVBQ1Q7QUFFQSxTQUFPLHVCQUFDLFNBQUksT0FBT0UsbUJBQW9CRixxQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF3QztBQUNqRDtBQUFDVSxLQWhCS1g7QUFrQk4sTUFBTVksTUFBTUEsTUFBTTtBQUFBQyxLQUFBO0FBQ2hCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJdkIsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ3dCLFVBQVVDLFdBQVcsSUFBSXpCLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUMwQixVQUFVQyxXQUFXLElBQUkzQixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDNEIsTUFBTUMsT0FBTyxJQUFJN0IsU0FBUyxJQUFJO0FBQ3JDLFFBQU0sQ0FBQzhCLGNBQWNDLGVBQWUsSUFBSS9CLFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUNnQyxPQUFPQyxRQUFRLElBQUlqQyxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDa0MsUUFBUUMsU0FBUyxJQUFJbkMsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ29DLEtBQUtDLE1BQU0sSUFBSXJDLFNBQVMsRUFBRTtBQUNqQyxRQUFNLENBQUNzQyxjQUFjQyxlQUFlLElBQUl2QyxTQUFTO0FBQUEsSUFBRVMsU0FBUztBQUFBLElBQU1DLE1BQU07QUFBQSxFQUFLLENBQUM7QUFFOUUsUUFBTThCLGNBQWN0QyxPQUFPO0FBRTNCRCxZQUFVLE1BQU07QUFDZCxVQUFNd0MsaUJBQWlCQyxPQUFPQyxhQUFhQyxRQUFRLG1CQUFtQjtBQUN0RSxRQUFJSCxnQkFBZ0I7QUFDbEIsWUFBTWIsUUFBT2lCLEtBQUtDLE1BQU1MLGNBQWM7QUFDdENaLGNBQVFELEtBQUk7QUFDWnRCLGtCQUFZeUMsU0FBU25CLE1BQUtvQixLQUFLO0FBRy9CLFlBQU1DLGFBQWEsWUFBWTtBQUM3QixZQUFJO0FBQ0YsZ0JBQU1DLGVBQWUsTUFBTTVDLFlBQVk2QyxPQUFPO0FBQzlDNUIsbUJBQVMyQixZQUFZO0FBQUEsUUFDdkIsU0FBU0UsT0FBTztBQUVkQyxrQkFBUUQsTUFBTSx5QkFBeUJBLEtBQUs7QUFDNUNiLDBCQUFnQjtBQUFBLFlBQUU5QixTQUFTO0FBQUEsWUFBd0JDLE1BQU07QUFBQSxVQUFRLENBQUM7QUFBQSxRQUNwRTtBQUFBLE1BQ0Y7QUFDQXVDLGlCQUFXO0FBQUEsSUFDYjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBR0wsUUFBTUssY0FBYyxPQUFPQyxVQUFVO0FBQ25DQSxVQUFNQyxlQUFlO0FBRXJCLFFBQUk7QUFDRixZQUFNNUIsUUFBTyxNQUFNckIsYUFBYWtELE1BQU07QUFBQSxRQUNwQ2pDO0FBQUFBLFFBQ0FFO0FBQUFBLE1BQ0YsQ0FBQztBQUNEZ0IsYUFBT0MsYUFBYWUsUUFBUSxxQkFBcUJiLEtBQUtjLFVBQVUvQixLQUFJLENBQUM7QUFDckV0QixrQkFBWXlDLFNBQVNuQixNQUFLb0IsS0FBSztBQUMvQm5CLGNBQVFELEtBQUk7QUFDWkgsa0JBQVksRUFBRTtBQUNkRSxrQkFBWSxFQUFFO0FBQ2QsWUFBTXVCLGVBQWUsTUFBTTVDLFlBQVk2QyxPQUFPO0FBQzlDNUIsZUFBUzJCLFlBQVk7QUFBQSxJQUN2QixTQUFTVSxXQUFXO0FBQ2xCckIsc0JBQWdCO0FBQUEsUUFBRTlCLFNBQVM7QUFBQSxRQUFxQkMsTUFBTTtBQUFBLE1BQVEsQ0FBQztBQUMvRG1ELGlCQUFXLE1BQU07QUFDZnRCLHdCQUFnQjtBQUFBLFVBQUU5QixTQUFTO0FBQUEsVUFBTUMsTUFBTTtBQUFBLFFBQUssQ0FBQztBQUFBLE1BQy9DLEdBQUcsR0FBSTtBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBRUEsUUFBTW9ELGVBQWVBLE1BQU07QUFDekJwQixXQUFPQyxhQUFhb0IsV0FBVyxtQkFBbUI7QUFDbERsQyxZQUFRLElBQUk7QUFDWnZCLGdCQUFZeUMsU0FBUyxJQUFJO0FBQ3pCUixvQkFBZ0I7QUFBQSxNQUFFOUIsU0FBUztBQUFBLE1BQTJCQyxNQUFNO0FBQUEsSUFBVSxDQUFDO0FBQ3ZFbUQsZUFBVyxNQUFNO0FBQ2Z0QixzQkFBZ0I7QUFBQSxRQUFFOUIsU0FBUztBQUFBLFFBQU1DLE1BQU07QUFBQSxNQUFLLENBQUM7QUFBQSxJQUMvQyxHQUFHLEdBQUk7QUFBQSxFQUNUO0FBRUEsUUFBTXNELFVBQVUsT0FBT0MsZUFBZTtBQUNwQyxRQUFJO0FBQ0YsWUFBTUMsZUFBZSxNQUFNNUQsWUFBWTZELE9BQU9GLFVBQVU7QUFDeEQsWUFBTWYsZUFBZSxNQUFNNUMsWUFBWTZDLE9BQU87QUFDOUM1QixlQUFTMkIsWUFBWTtBQUNyQlYsa0JBQVk0QixRQUFRQyxpQkFBaUI7QUFDckM5QixzQkFBZ0I7QUFBQSxRQUNkOUIsU0FBVSxtQkFBa0J5RCxhQUFhbEMsS0FBTSxPQUFNa0MsYUFBYWhDLE1BQU87QUFBQSxRQUN6RXhCLE1BQU07QUFBQSxNQUNSLENBQUM7QUFDRG1ELGlCQUFXLE1BQU07QUFDZnRCLHdCQUFnQjtBQUFBLFVBQUU5QixTQUFTO0FBQUEsVUFBTUMsTUFBTTtBQUFBLFFBQUssQ0FBQztBQUFBLE1BQy9DLEdBQUcsR0FBSTtBQUFBLElBQ1QsU0FBUzBDLE9BQU87QUFDZGIsc0JBQWdCO0FBQUEsUUFBRTlCLFNBQVM7QUFBQSxRQUFzQkMsTUFBTTtBQUFBLE1BQVEsQ0FBQztBQUNoRW1ELGlCQUFXLE1BQU07QUFDZnRCLHdCQUFnQjtBQUFBLFVBQUU5QixTQUFTO0FBQUEsVUFBTUMsTUFBTTtBQUFBLFFBQUssQ0FBQztBQUFBLE1BQy9DLEdBQUcsR0FBSTtBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBRUEsUUFBTTRELGFBQWFBLENBQUNDLElBQUlDLGdCQUFnQjtBQUN0Q2pELGFBQVNELE1BQU1tRCxJQUFJQyxVQUFRQSxLQUFLSCxPQUFPQSxLQUFLQyxjQUFjRSxJQUFJLENBQUM7QUFBQSxFQUNqRTtBQUVBLFFBQU1DLFlBQVlBLE1BQ2hCLHVCQUFDLFVBQUssVUFBVXJCLGFBQ2Q7QUFBQSwyQkFBQyxTQUFHO0FBQUE7QUFBQSxNQUVGLHVCQUFDLFdBQU0sTUFBSyxRQUNWLE9BQU85QixVQUNQLE1BQUssWUFDTCxVQUFVLENBQUM7QUFBQSxRQUFFb0Q7QUFBQUEsTUFBTyxNQUFNbkQsWUFBWW1ELE9BQU9DLEtBQUssS0FIcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdzRDtBQUFBLFNBTHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBQ0EsdUJBQUMsU0FBRztBQUFBO0FBQUEsTUFFRix1QkFBQyxXQUFNLE1BQUssWUFDVixPQUFPbkQsVUFDUCxNQUFLLFlBQ0wsVUFBVSxDQUFDO0FBQUEsUUFBRWtEO0FBQUFBLE1BQU8sTUFBTWpELFlBQVlpRCxPQUFPQyxLQUFLLEtBSHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHc0Q7QUFBQSxTQUx4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLHFCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJCO0FBQUEsT0FqQjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrQkE7QUFHRixRQUFNQyxjQUFjeEQsTUFBTXlELEtBQUssQ0FBQ0MsR0FBR0MsTUFBTUEsRUFBRUMsUUFBUUYsRUFBRUUsS0FBSztBQUcxRCxTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxRQUFHLHFCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUztBQUFBLElBQ1QsdUJBQUMsZ0JBQWEsU0FBUzVDLGFBQWE3QixTQUFTLE1BQU02QixhQUFhNUIsUUFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxRTtBQUFBLElBQ3BFa0IsU0FBUyxPQUNSLHVCQUFDLFNBQ0M7QUFBQSw2QkFBQyxRQUFHLHFDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUI7QUFBQSxNQUN4QitDLFVBQVU7QUFBQSxTQUZiO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQSxJQUVBLHVCQUFDLFNBQ0M7QUFBQSw2QkFBQyxPQUFDO0FBQUE7QUFBQSxRQUNVL0MsS0FBS3VEO0FBQUFBLFFBQUs7QUFBQSxRQUFFO0FBQUEsUUFDdEIsdUJBQUMsWUFBTyxTQUFTckIsY0FBYyxzQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxQztBQUFBLFdBRnZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsYUFBVSxhQUFZLFlBQVcsS0FBS3RCLGFBQ3JDLGlDQUFDLFlBQVMsWUFBWXdCLFdBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEIsS0FEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsYUFDWmMsc0JBQVlMLElBQUtDLFVBQ2hCLHVCQUFDLFFBQW1CLE1BQVksTUFBWSxVQUFvQixPQUFjLGNBQW5FQSxLQUFLSCxJQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFHLENBQ3RHLEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsU0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUE7QUFBQSxPQXRCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd0JBO0FBRUo7QUFBQ2xELEdBbEpLRCxLQUFHO0FBQUFnRSxNQUFIaEU7QUFvSk4sZUFBZUE7QUFBRyxJQUFBRCxJQUFBaUU7QUFBQUMsYUFBQWxFLElBQUE7QUFBQWtFLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZVJlZiIsIkJsb2ciLCJCbG9nRm9ybSIsIlRvZ2dsYWJsZSIsImJsb2dTZXJ2aWNlIiwibG9naW5TZXJ2aWNlIiwiTm90aWZpY2F0aW9uIiwibWVzc2FnZSIsInR5cGUiLCJub3RpZmljYXRpb25TdHlsZSIsImNvbG9yIiwiYmFja2dyb3VuZCIsImZvbnRTaXplIiwiYm9yZGVyU3R5bGUiLCJib3JkZXJSYWRpdXMiLCJwYWRkaW5nIiwibWFyZ2luQm90dG9tIiwiX2MiLCJBcHAiLCJfcyIsImJsb2dzIiwic2V0QmxvZ3MiLCJ1c2VybmFtZSIsInNldFVzZXJuYW1lIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsInVzZXIiLCJzZXRVc2VyIiwiZXJyb3JNZXNzYWdlIiwic2V0RXJyb3JNZXNzYWdlIiwidGl0bGUiLCJzZXRUaXRsZSIsImF1dGhvciIsInNldEF1dGhvciIsInVybCIsInNldFVybCIsIm5vdGlmaWNhdGlvbiIsInNldE5vdGlmaWNhdGlvbiIsImJsb2dGb3JtUmVmIiwibG9nZ2VkVXNlckpTT04iLCJ3aW5kb3ciLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwiSlNPTiIsInBhcnNlIiwic2V0VG9rZW4iLCJ0b2tlbiIsImZldGNoQmxvZ3MiLCJmZXRjaGVkQmxvZ3MiLCJnZXRBbGwiLCJlcnJvciIsImNvbnNvbGUiLCJoYW5kbGVMb2dpbiIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJsb2dpbiIsInNldEl0ZW0iLCJzdHJpbmdpZnkiLCJleGNlcHRpb24iLCJzZXRUaW1lb3V0IiwiaGFuZGxlTG9nb3V0IiwicmVtb3ZlSXRlbSIsImFkZEJsb2ciLCJibG9nT2JqZWN0IiwicmV0dXJuZWRCbG9nIiwiY3JlYXRlIiwiY3VycmVudCIsInRvZ2dsZVZpc2liaWxpdHkiLCJ1cGRhdGVCbG9nIiwiaWQiLCJ1cGRhdGVkQmxvZyIsIm1hcCIsImJsb2ciLCJsb2dpbkZvcm0iLCJ0YXJnZXQiLCJ2YWx1ZSIsInNvcnRlZEJsb2dzIiwic29ydCIsImEiLCJiIiwibGlrZXMiLCJuYW1lIiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXBwLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tICdyZWFjdCdcbmltcG9ydCBCbG9nIGZyb20gJy4vY29tcG9uZW50cy9CbG9nJ1xuaW1wb3J0IEJsb2dGb3JtIGZyb20gJy4vY29tcG9uZW50cy9CbG9nRm9ybSdcbmltcG9ydCBUb2dnbGFibGUgZnJvbSAnLi9jb21wb25lbnRzL1RvZ2dsYWJsZSdcbmltcG9ydCBibG9nU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL2Jsb2dzJ1xuaW1wb3J0IGxvZ2luU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL2xvZ2luJ1xuXG5cbmNvbnN0IE5vdGlmaWNhdGlvbiA9ICh7IG1lc3NhZ2UsIHR5cGUgfSkgPT4ge1xuICBjb25zdCBub3RpZmljYXRpb25TdHlsZSA9IHtcbiAgICBjb2xvcjogdHlwZSA9PT0gJ2Vycm9yJyA/ICdyZWQnIDogJ2dyZWVuJyxcbiAgICBiYWNrZ3JvdW5kOiAnbGlnaHRncmV5JyxcbiAgICBmb250U2l6ZTogJzIwcHgnLFxuICAgIGJvcmRlclN0eWxlOiAnc29saWQnLFxuICAgIGJvcmRlclJhZGl1czogJzVweCcsXG4gICAgcGFkZGluZzogJzEwcHgnLFxuICAgIG1hcmdpbkJvdHRvbTogJzEwcHgnLFxuICB9XG5cbiAgaWYgKG1lc3NhZ2UgPT09IG51bGwpIHtcbiAgICByZXR1cm4gbnVsbFxuICB9XG5cbiAgcmV0dXJuIDxkaXYgc3R5bGU9e25vdGlmaWNhdGlvblN0eWxlfT57bWVzc2FnZX08L2Rpdj5cbn1cblxuY29uc3QgQXBwID0gKCkgPT4ge1xuICBjb25zdCBbYmxvZ3MsIHNldEJsb2dzXSA9IHVzZVN0YXRlKFtdKVxuICBjb25zdCBbdXNlcm5hbWUsIHNldFVzZXJuYW1lXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbdXNlciwgc2V0VXNlcl0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbZXJyb3JNZXNzYWdlLCBzZXRFcnJvck1lc3NhZ2VdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW3RpdGxlLCBzZXRUaXRsZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW2F1dGhvciwgc2V0QXV0aG9yXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbdXJsLCBzZXRVcmxdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtub3RpZmljYXRpb24sIHNldE5vdGlmaWNhdGlvbl0gPSB1c2VTdGF0ZSh7IG1lc3NhZ2U6IG51bGwsIHR5cGU6IG51bGwgfSlcblxuICBjb25zdCBibG9nRm9ybVJlZiA9IHVzZVJlZigpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBsb2dnZWRVc2VySlNPTiA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnbG9nZ2VkQmxvZ0FwcFVzZXInKVxuICAgIGlmIChsb2dnZWRVc2VySlNPTikge1xuICAgICAgY29uc3QgdXNlciA9IEpTT04ucGFyc2UobG9nZ2VkVXNlckpTT04pXG4gICAgICBzZXRVc2VyKHVzZXIpXG4gICAgICBibG9nU2VydmljZS5zZXRUb2tlbih1c2VyLnRva2VuKVxuXG4gICAgICAvLyBGZXRjaCBibG9ncyBhZnRlciB0aGUgdXNlciBoYXMgbG9nZ2VkIGluXG4gICAgICBjb25zdCBmZXRjaEJsb2dzID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IGZldGNoZWRCbG9ncyA9IGF3YWl0IGJsb2dTZXJ2aWNlLmdldEFsbCgpXG4gICAgICAgICAgc2V0QmxvZ3MoZmV0Y2hlZEJsb2dzKVxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgIC8vIEhhbmRsZSBlcnJvclxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGZldGNoaW5nIGJsb2dzOicsIGVycm9yKVxuICAgICAgICAgIHNldE5vdGlmaWNhdGlvbih7IG1lc3NhZ2U6ICdFcnJvciBmZXRjaGluZyBibG9ncycsIHR5cGU6ICdlcnJvcicgfSlcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgZmV0Y2hCbG9ncygpXG4gICAgfVxuICB9LCBbXSlcblxuXG4gIGNvbnN0IGhhbmRsZUxvZ2luID0gYXN5bmMgKGV2ZW50KSA9PiB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHVzZXIgPSBhd2FpdCBsb2dpblNlcnZpY2UubG9naW4oe1xuICAgICAgICB1c2VybmFtZSxcbiAgICAgICAgcGFzc3dvcmQsXG4gICAgICB9KVxuICAgICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKCdsb2dnZWRCbG9nQXBwVXNlcicsIEpTT04uc3RyaW5naWZ5KHVzZXIpKVxuICAgICAgYmxvZ1NlcnZpY2Uuc2V0VG9rZW4odXNlci50b2tlbilcbiAgICAgIHNldFVzZXIodXNlcilcbiAgICAgIHNldFVzZXJuYW1lKCcnKVxuICAgICAgc2V0UGFzc3dvcmQoJycpXG4gICAgICBjb25zdCBmZXRjaGVkQmxvZ3MgPSBhd2FpdCBibG9nU2VydmljZS5nZXRBbGwoKVxuICAgICAgc2V0QmxvZ3MoZmV0Y2hlZEJsb2dzKVxuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgc2V0Tm90aWZpY2F0aW9uKHsgbWVzc2FnZTogJ1dyb25nIGNyZWRlbnRpYWxzJywgdHlwZTogJ2Vycm9yJyB9KVxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHNldE5vdGlmaWNhdGlvbih7IG1lc3NhZ2U6IG51bGwsIHR5cGU6IG51bGwgfSlcbiAgICAgIH0sIDUwMDApXG4gICAgfVxuICB9XG5cbiAgY29uc3QgaGFuZGxlTG9nb3V0ID0gKCkgPT4ge1xuICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnbG9nZ2VkQmxvZ0FwcFVzZXInKVxuICAgIHNldFVzZXIobnVsbClcbiAgICBibG9nU2VydmljZS5zZXRUb2tlbihudWxsKVxuICAgIHNldE5vdGlmaWNhdGlvbih7IG1lc3NhZ2U6ICdMb2dnZWQgb3V0IHN1Y2Nlc3NmdWxseScsIHR5cGU6ICdzdWNjZXNzJyB9KVxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgc2V0Tm90aWZpY2F0aW9uKHsgbWVzc2FnZTogbnVsbCwgdHlwZTogbnVsbCB9KVxuICAgIH0sIDUwMDApXG4gIH1cblxuICBjb25zdCBhZGRCbG9nID0gYXN5bmMgKGJsb2dPYmplY3QpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmV0dXJuZWRCbG9nID0gYXdhaXQgYmxvZ1NlcnZpY2UuY3JlYXRlKGJsb2dPYmplY3QpXG4gICAgICBjb25zdCBmZXRjaGVkQmxvZ3MgPSBhd2FpdCBibG9nU2VydmljZS5nZXRBbGwoKVxuICAgICAgc2V0QmxvZ3MoZmV0Y2hlZEJsb2dzKVxuICAgICAgYmxvZ0Zvcm1SZWYuY3VycmVudC50b2dnbGVWaXNpYmlsaXR5KClcbiAgICAgIHNldE5vdGlmaWNhdGlvbih7XG4gICAgICAgIG1lc3NhZ2U6IGBBZGRlZCBuZXcgYmxvZzogJHtyZXR1cm5lZEJsb2cudGl0bGV9IGJ5ICR7cmV0dXJuZWRCbG9nLmF1dGhvcn1gLFxuICAgICAgICB0eXBlOiAnc3VjY2VzcycsXG4gICAgICB9KVxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHNldE5vdGlmaWNhdGlvbih7IG1lc3NhZ2U6IG51bGwsIHR5cGU6IG51bGwgfSlcbiAgICAgIH0sIDUwMDApXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHNldE5vdGlmaWNhdGlvbih7IG1lc3NhZ2U6ICdGYWlsZWQgdG8gYWRkIGJsb2cnLCB0eXBlOiAnZXJyb3InIH0pXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgc2V0Tm90aWZpY2F0aW9uKHsgbWVzc2FnZTogbnVsbCwgdHlwZTogbnVsbCB9KVxuICAgICAgfSwgNTAwMClcbiAgICB9XG4gIH1cblxuICBjb25zdCB1cGRhdGVCbG9nID0gKGlkLCB1cGRhdGVkQmxvZykgPT4ge1xuICAgIHNldEJsb2dzKGJsb2dzLm1hcChibG9nID0+IGJsb2cuaWQgPT09IGlkID8gdXBkYXRlZEJsb2cgOiBibG9nKSlcbiAgfVxuXG4gIGNvbnN0IGxvZ2luRm9ybSA9ICgpID0+IChcbiAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlTG9naW59PlxuICAgICAgPGRpdj5cbiAgICAgICAgVXNlcm5hbWVcbiAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICB2YWx1ZT17dXNlcm5hbWV9XG4gICAgICAgICAgbmFtZT1cIlVzZXJuYW1lXCJcbiAgICAgICAgICBvbkNoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldFVzZXJuYW1lKHRhcmdldC52YWx1ZSl9XG4gICAgICAgIC8+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXY+XG4gICAgICAgIFBhc3N3b3JkXG4gICAgICAgIDxpbnB1dCB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cbiAgICAgICAgICBuYW1lPVwiUGFzc3dvcmRcIlxuICAgICAgICAgIG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0UGFzc3dvcmQodGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgLz5cbiAgICAgIDwvZGl2PlxuICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCI+bG9naW48L2J1dHRvbj5cbiAgICA8L2Zvcm0+XG4gIClcblxuICBjb25zdCBzb3J0ZWRCbG9ncyA9IGJsb2dzLnNvcnQoKGEsIGIpID0+IGIubGlrZXMgLSBhLmxpa2VzKVxuXG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGgyPkJsb2dzPC9oMj5cbiAgICAgIDxOb3RpZmljYXRpb24gbWVzc2FnZT17bm90aWZpY2F0aW9uLm1lc3NhZ2V9IHR5cGU9e25vdGlmaWNhdGlvbi50eXBlfSAvPlxuICAgICAge3VzZXIgPT09IG51bGwgPyAoXG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGgyPkxvZyBpbiB0byBhcHBsaWNhdGlvbjwvaDI+XG4gICAgICAgICAge2xvZ2luRm9ybSgpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICkgOiAoXG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPHA+XG4gICAgICAgICAgICBXZWxjb21lLCB7dXNlci5uYW1lfSF7JyAnfVxuICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtoYW5kbGVMb2dvdXR9PkxvZ291dDwvYnV0dG9uPlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8VG9nZ2xhYmxlIGJ1dHRvbkxhYmVsPVwiTmV3IEJsb2dcIiByZWY9e2Jsb2dGb3JtUmVmfT5cbiAgICAgICAgICAgIDxCbG9nRm9ybSBjcmVhdGVCbG9nPXthZGRCbG9nfSAvPlxuICAgICAgICAgIDwvVG9nZ2xhYmxlPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdibG9nLWxpc3QnPlxuICAgICAgICAgICAge3NvcnRlZEJsb2dzLm1hcCgoYmxvZykgPT4gKFxuICAgICAgICAgICAgICA8QmxvZyBrZXk9e2Jsb2cuaWR9IGJsb2c9e2Jsb2d9IHVzZXI9e3VzZXJ9IHNldEJsb2dzPXtzZXRCbG9nc30gYmxvZ3M9e2Jsb2dzfSB1cGRhdGVCbG9nPXt1cGRhdGVCbG9nfS8+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcCJdLCJmaWxlIjoiL1VzZXJzL2FudG9uZGVtaW4vUmVhY3RQcm9qZWN0cy9GdWxsU3RhY2tDb3Vyc2UvUGFydDUvYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL0FwcC5qc3gifQ==