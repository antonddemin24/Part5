import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Togglable.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0a8c374f"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Togglable.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=0a8c374f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const forwardRef = __vite__cjsImport3_react["forwardRef"]; const useImperativeHandle = __vite__cjsImport3_react["useImperativeHandle"];
const Togglable = _s(forwardRef(_c = _s((props, ref) => {
  _s();
  const [visible, setVisible] = useState(false);
  const hideWhenVisible = {
    display: visible ? "none" : ""
  };
  const showWhenVisible = {
    display: visible ? "" : "none"
  };
  const toggleVisibility = () => {
    setVisible(!visible);
  };
  useImperativeHandle(ref, () => {
    return {
      toggleVisibility
    };
  });
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { style: hideWhenVisible, children: /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: props.buttonLabel }, void 0, false, {
      fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Togglable.jsx",
      lineNumber: 22,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Togglable.jsx",
      lineNumber: 21,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: showWhenVisible, children: [
      props.children,
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: "cancel" }, void 0, false, {
        fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Togglable.jsx",
        lineNumber: 26,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Togglable.jsx",
      lineNumber: 24,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Togglable.jsx",
    lineNumber: 20,
    columnNumber: 10
  }, this);
}, "7Y5lBLdF9mkfoiy3F9Lk5HPUzvA=")), "7Y5lBLdF9mkfoiy3F9Lk5HPUzvA=");
_c2 = Togglable;
Togglable.displayName = "Togglable";
export default Togglable;
var _c, _c2;
$RefreshReg$(_c, "Togglable$forwardRef");
$RefreshReg$(_c2, "Togglable");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/Togglable.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJROzs7Ozs7Ozs7Ozs7Ozs7OztBQXJCUixPQUFPQSxTQUFTQyxVQUFVQyxZQUFZQywyQkFBMkI7QUFFakUsTUFBTUMsWUFBU0MsR0FBR0gsV0FBVUksS0FBQUQsR0FBQyxDQUFDRSxPQUFPQyxRQUFRO0FBQUFILEtBQUE7QUFDM0MsUUFBTSxDQUFDSSxTQUFTQyxVQUFVLElBQUlULFNBQVMsS0FBSztBQUU1QyxRQUFNVSxrQkFBa0I7QUFBQSxJQUFFQyxTQUFTSCxVQUFVLFNBQVM7QUFBQSxFQUFHO0FBQ3pELFFBQU1JLGtCQUFrQjtBQUFBLElBQUVELFNBQVNILFVBQVUsS0FBSztBQUFBLEVBQU87QUFFekQsUUFBTUssbUJBQW1CQSxNQUFNO0FBQzdCSixlQUFXLENBQUNELE9BQU87QUFBQSxFQUNyQjtBQUVBTixzQkFBb0JLLEtBQUssTUFBTTtBQUM3QixXQUFPO0FBQUEsTUFDTE07QUFBQUEsSUFDRjtBQUFBLEVBQ0YsQ0FBQztBQUVELFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFNBQUksT0FBT0gsaUJBQ1YsaUNBQUMsWUFBTyxTQUFTRyxrQkFBbUJQLGdCQUFNUSxlQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNELEtBRHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxPQUFPRixpQkFDVE47QUFBQUEsWUFBTVM7QUFBQUEsTUFDUCx1QkFBQyxZQUFPLFNBQVNGLGtCQUFrQixzQkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QztBQUFBLFNBRjNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLE9BUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBO0FBRUosR0FBQyxrQ0FBQztBQUFBRyxNQTNCSWI7QUE2Qk5BLFVBQVVjLGNBQWM7QUFFeEIsZUFBZWQ7QUFBUyxJQUFBRSxJQUFBVztBQUFBRSxhQUFBYixJQUFBO0FBQUFhLGFBQUFGLEtBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwiZm9yd2FyZFJlZiIsInVzZUltcGVyYXRpdmVIYW5kbGUiLCJUb2dnbGFibGUiLCJfcyIsIl9jIiwicHJvcHMiLCJyZWYiLCJ2aXNpYmxlIiwic2V0VmlzaWJsZSIsImhpZGVXaGVuVmlzaWJsZSIsImRpc3BsYXkiLCJzaG93V2hlblZpc2libGUiLCJ0b2dnbGVWaXNpYmlsaXR5IiwiYnV0dG9uTGFiZWwiLCJjaGlsZHJlbiIsIl9jMiIsImRpc3BsYXlOYW1lIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVG9nZ2xhYmxlLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIGZvcndhcmRSZWYsIHVzZUltcGVyYXRpdmVIYW5kbGUgfSBmcm9tICdyZWFjdCdcblxuY29uc3QgVG9nZ2xhYmxlID0gZm9yd2FyZFJlZigocHJvcHMsIHJlZikgPT4ge1xuICBjb25zdCBbdmlzaWJsZSwgc2V0VmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSlcblxuICBjb25zdCBoaWRlV2hlblZpc2libGUgPSB7IGRpc3BsYXk6IHZpc2libGUgPyAnbm9uZScgOiAnJyB9XG4gIGNvbnN0IHNob3dXaGVuVmlzaWJsZSA9IHsgZGlzcGxheTogdmlzaWJsZSA/ICcnIDogJ25vbmUnIH1cblxuICBjb25zdCB0b2dnbGVWaXNpYmlsaXR5ID0gKCkgPT4ge1xuICAgIHNldFZpc2libGUoIXZpc2libGUpXG4gIH1cblxuICB1c2VJbXBlcmF0aXZlSGFuZGxlKHJlZiwgKCkgPT4ge1xuICAgIHJldHVybiB7XG4gICAgICB0b2dnbGVWaXNpYmlsaXR5LFxuICAgIH1cbiAgfSlcblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8ZGl2IHN0eWxlPXtoaWRlV2hlblZpc2libGV9PlxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e3RvZ2dsZVZpc2liaWxpdHl9Pntwcm9wcy5idXR0b25MYWJlbH08L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBzdHlsZT17c2hvd1doZW5WaXNpYmxlfT5cbiAgICAgICAge3Byb3BzLmNoaWxkcmVufVxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e3RvZ2dsZVZpc2liaWxpdHl9PmNhbmNlbDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIClcbn0pXG5cblRvZ2dsYWJsZS5kaXNwbGF5TmFtZSA9ICdUb2dnbGFibGUnXG5cbmV4cG9ydCBkZWZhdWx0IFRvZ2dsYWJsZSJdLCJmaWxlIjoiL1VzZXJzL2FudG9uZGVtaW4vUmVhY3RQcm9qZWN0cy9GdWxsU3RhY2tDb3Vyc2UvUGFydDUvYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvVG9nZ2xhYmxlLmpzeCJ9