import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BlogForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0a8c374f"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/BlogForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=0a8c374f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
const BlogForm = ({
  createBlog
}) => {
  _s();
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [url, setUrl] = useState("");
  const handleSubmit = (event) => {
    event.preventDefault();
    createBlog({
      title,
      author,
      url
    });
    setTitle("");
    setAuthor("");
    setUrl("");
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Create New Blog" }, void 0, false, {
      fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 22,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        "title",
        /* @__PURE__ */ jsxDEV("input", { "data-testid": "title", type: "text", value: title, onChange: ({
          target
        }) => setTitle(target.value), id: "blog-title" }, void 0, false, {
          fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/BlogForm.jsx",
          lineNumber: 26,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 24,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "author",
        /* @__PURE__ */ jsxDEV("input", { "data-testid": "author", type: "text", value: author, onChange: ({
          target
        }) => setAuthor(target.value), id: "blog-author" }, void 0, false, {
          fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/BlogForm.jsx",
          lineNumber: 32,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 30,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "url",
        /* @__PURE__ */ jsxDEV("input", { "data-testid": "url", type: "text", value: url, onChange: ({
          target
        }) => setUrl(target.value), id: "blog-url" }, void 0, false, {
          fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/BlogForm.jsx",
          lineNumber: 38,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 36,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "create" }, void 0, false, {
        fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 42,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 23,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/BlogForm.jsx",
    lineNumber: 21,
    columnNumber: 10
  }, this);
};
_s(BlogForm, "g+g+3j1LiFjJCP23+NliFDHOHt4=");
_c = BlogForm;
export default BlogForm;
var _c;
$RefreshReg$(_c, "BlogForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/antondemin/ReactProjects/FullStackCourse/Part5/bloglist-frontend/src/components/BlogForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXJCTixPQUFPQSxTQUFTQyxnQkFBZ0I7QUFFaEMsTUFBTUMsV0FBV0EsQ0FBQztBQUFBLEVBQUVDO0FBQVcsTUFBTTtBQUFBQyxLQUFBO0FBQ25DLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJTCxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDTSxRQUFRQyxTQUFTLElBQUlQLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNRLEtBQUtDLE1BQU0sSUFBSVQsU0FBUyxFQUFFO0FBRWpDLFFBQU1VLGVBQWdCQyxXQUFVO0FBQzlCQSxVQUFNQyxlQUFlO0FBQ3JCVixlQUFXO0FBQUEsTUFDVEU7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQUU7QUFBQUEsSUFDRixDQUFDO0FBQ0RILGFBQVMsRUFBRTtBQUNYRSxjQUFVLEVBQUU7QUFDWkUsV0FBTyxFQUFFO0FBQUEsRUFDWDtBQUVBLFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFFBQUcsK0JBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtQjtBQUFBLElBQ25CLHVCQUFDLFVBQUssVUFBVUMsY0FDZDtBQUFBLDZCQUFDLFNBQUc7QUFBQTtBQUFBLFFBRUYsdUJBQUMsV0FDQyxlQUFZLFNBQ1osTUFBSyxRQUNMLE9BQU9OLE9BQ1AsVUFBVSxDQUFDO0FBQUEsVUFBRVM7QUFBQUEsUUFBTyxNQUFNUixTQUFTUSxPQUFPQyxLQUFLLEdBQy9DLElBQUcsZ0JBTEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtpQjtBQUFBLFdBUG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BQ0EsdUJBQUMsU0FBRztBQUFBO0FBQUEsUUFFRix1QkFBQyxXQUNDLGVBQVksVUFDWixNQUFLLFFBQ0wsT0FBT1IsUUFDUCxVQUFVLENBQUM7QUFBQSxVQUFFTztBQUFBQSxRQUFPLE1BQU1OLFVBQVVNLE9BQU9DLEtBQUssR0FDaEQsSUFBRyxpQkFMTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS2tCO0FBQUEsV0FQcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFDQSx1QkFBQyxTQUFHO0FBQUE7QUFBQSxRQUVGLHVCQUFDLFdBQ0MsZUFBWSxPQUNaLE1BQUssUUFDTCxPQUFPTixLQUNQLFVBQVUsQ0FBQztBQUFBLFVBQUVLO0FBQUFBLFFBQU8sTUFBTUosT0FBT0ksT0FBT0MsS0FBSyxHQUM3QyxJQUFHLGNBTEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtlO0FBQUEsV0FQakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxzQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0QjtBQUFBLFNBL0I5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0NBO0FBQUEsT0FsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1DQTtBQUVKO0FBQUNYLEdBdkRLRixVQUFRO0FBQUFjLEtBQVJkO0FBeUROLGVBQWVBO0FBQVEsSUFBQWM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJCbG9nRm9ybSIsImNyZWF0ZUJsb2ciLCJfcyIsInRpdGxlIiwic2V0VGl0bGUiLCJhdXRob3IiLCJzZXRBdXRob3IiLCJ1cmwiLCJzZXRVcmwiLCJoYW5kbGVTdWJtaXQiLCJldmVudCIsInByZXZlbnREZWZhdWx0IiwidGFyZ2V0IiwidmFsdWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkJsb2dGb3JtLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcblxuY29uc3QgQmxvZ0Zvcm0gPSAoeyBjcmVhdGVCbG9nIH0pID0+IHtcbiAgY29uc3QgW3RpdGxlLCBzZXRUaXRsZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW2F1dGhvciwgc2V0QXV0aG9yXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbdXJsLCBzZXRVcmxdID0gdXNlU3RhdGUoJycpXG5cbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gKGV2ZW50KSA9PiB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxuICAgIGNyZWF0ZUJsb2coe1xuICAgICAgdGl0bGUsXG4gICAgICBhdXRob3IsXG4gICAgICB1cmwsXG4gICAgfSlcbiAgICBzZXRUaXRsZSgnJylcbiAgICBzZXRBdXRob3IoJycpXG4gICAgc2V0VXJsKCcnKVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGgyPkNyZWF0ZSBOZXcgQmxvZzwvaDI+XG4gICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fT5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICB0aXRsZVxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgZGF0YS10ZXN0aWQ9J3RpdGxlJ1xuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgdmFsdWU9e3RpdGxlfVxuICAgICAgICAgICAgb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRUaXRsZSh0YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgaWQ9J2Jsb2ctdGl0bGUnXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgYXV0aG9yXG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICBkYXRhLXRlc3RpZD0nYXV0aG9yJ1xuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgdmFsdWU9e2F1dGhvcn1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0QXV0aG9yKHRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBpZD0nYmxvZy1hdXRob3InXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgdXJsXG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICBkYXRhLXRlc3RpZD0ndXJsJ1xuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgdmFsdWU9e3VybH1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0VXJsKHRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBpZD0nYmxvZy11cmwnXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiPmNyZWF0ZTwvYnV0dG9uPlxuICAgICAgPC9mb3JtPlxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEJsb2dGb3JtIl0sImZpbGUiOiIvVXNlcnMvYW50b25kZW1pbi9SZWFjdFByb2plY3RzL0Z1bGxTdGFja0NvdXJzZS9QYXJ0NS9ibG9nbGlzdC1mcm9udGVuZC9zcmMvY29tcG9uZW50cy9CbG9nRm9ybS5qc3gifQ==